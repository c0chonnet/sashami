WP Plugin for maintaining an interactive map of Tartu paintings by Sashami
[sashami.opsti.ee](https://sashami.opsti.ee)

## Changelog

- 1.1.0 - Logic for uploading and displaying multiple artworks of one building
- 1.0.0 - The admin page is ready for uploading artworks