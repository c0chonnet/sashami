<?php

die('Denied');